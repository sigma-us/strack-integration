module.exports = stravaController;

function stravaController() {
    return {
        
    }
}